/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Parqueadero.modelo;

/**
 *
 * @author Hp
 */

class Puesto {
    private int numero;
    private String placa;

    Puesto(int numero) {
        this.numero = numero;
        this.placa = null;
    }

    public int getNumero() { return numero; }
    public String getPlaca() { return placa; }
    public boolean estaLibre() { return placa == null; }
    public void ocupar(String placa) { this.placa = placa; }
    public void liberar() { this.placa = null; }
}
